This is a yalmCamp Project where we have to perform CRUD(Create, read, update and Delete) operation and review our camp site.
We have to store the documentation on the MongoDB Database.(i.e. MongoDB Atlas)

Make sure you have an account in MongoDB Atlas. Also you can download POSTMAN to check the routing activities.

After you have to download different dependencies.

on this project i upload my content to cloud through cloudinary.
So you have to create a cloudinary account and use these data on ".env" file.
CLOUDINARY_CLOUD_NAME=cloudinary_name,
CLOUDINARY_KEY=key_name,
CLOUDINARY_SECRET=secret_key.


****************

first run the 'node seeds/index.js' - to upload some initial data to mongodb database
second run 'node app.js' - to run whole project on localhost:8000 in the browser

*****************
